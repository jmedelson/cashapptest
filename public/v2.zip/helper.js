window.addEventListener('message', (event) => {
  console.log(event);
});
//debugger;
//const local = window.frameElement.attributes.getNamedItem('helperUrl');
//const online = 'https://extension-files.twitch.tv/helper/v1/twitch-ext.min.js';
//const el = document.createElement('script');
//el.src = local ? local.value : online;
//document.head.appendChild(el);
